import argparse
import pickle
import numpy as np
import json
import autosklearn.metrics
from autosklearn.classification import AutoSklearnClassifier as Classifier
from pathlib import Path
from datasets import load_from_disk

from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    f1_score, precision_score, recall_score, roc_auc_score, average_precision_score,
    matthews_corrcoef, balanced_accuracy_score,
)

from metrics.config import TOTAL_TIME, N_JOBS, MAX_NUM_METRICS, BEST_MRMR as SELECTED_METRICS
from metrics.util import calculate_vul_det_score, best_threshold


def run_train_autosklearn(data_dir: Path, metric_subset: bool, job_id: int) -> None:
    num_metrics = len(SELECTED_METRICS)
    if metric_subset:
        num_metrics = (job_id % num_metrics) + 1
    selected_metrics = SELECTED_METRICS[:num_metrics]

    # Output directory
    output_dir = data_dir / "autosklearn-model" / str(num_metrics) / str(job_id)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load data
    datasets = load_from_disk(data_dir)
    train_features = np.array([datasets["train"][k] for k in selected_metrics]).T
    val_features = np.array([datasets["val"][k] for k in selected_metrics]).T
    test_features = np.array([datasets["test"][k] for k in selected_metrics]).T

    print(f"train_features.shape: {train_features.shape}")
    print(f"val_features.shape: {val_features.shape}")
    print(f"test_features.shape: {test_features.shape}")
    print(f"selected_metrics: {selected_metrics}")

    train_labels = np.array(datasets["train"]["labels"])
    val_labels = np.array(datasets["val"]["labels"])
    test_labels = np.array(datasets["test"]["labels"])

    # Fix: auto-sklearn cannot produce good models for low dimensional inputs.
    # Adding random features fixed this at the expense of a slight overall
    # performance drop.
    num_missing = MAX_NUM_METRICS - num_metrics
    if num_missing > 0:
        train_features = np.concatenate([train_features, np.random.rand(train_features.shape[0], num_missing)], axis=1)
        val_features = np.concatenate([val_features, np.random.rand(val_features.shape[0], num_missing)], axis=1)
        test_features = np.concatenate([test_features, np.random.rand(test_features.shape[0], num_missing)], axis=1)

    # Scale data
    scaler = StandardScaler().fit(train_features)
    train_scaled = scaler.transform(train_features)
    val_scaled = scaler.transform(val_features)
    test_scaled = scaler.transform(test_features)

    # Non-exhaustive cross validation
    selected_indices = np.random.choice(np.arange(len(train_scaled)), int(len(train_scaled) * 0.9))
    train_scaled = train_scaled[selected_indices]
    train_labels = train_labels[selected_indices]

    automl = Classifier(
        time_left_for_this_task=TOTAL_TIME,
        n_jobs=N_JOBS,
        memory_limit=8192,
        metric=autosklearn.metrics.f1,
    )
    automl = automl.fit(train_scaled, train_labels)

    print(automl.leaderboard())
    prediction_scores = automl.predict_proba(val_scaled)[:, 1]
    threshold = best_threshold(f1_score, val_labels, prediction_scores)
    prediction_scores = automl.predict_proba(test_scaled)[:, 1]
    predictions = prediction_scores > threshold
    metrics = {
        "AUC": roc_auc_score(test_labels, prediction_scores),
        "AP": average_precision_score(test_labels, prediction_scores),
        "VD-S": calculate_vul_det_score(test_labels, prediction_scores),
        "MCC": matthews_corrcoef(test_labels, predictions),
        "BAcc": balanced_accuracy_score(test_labels, predictions),
        "F1": f1_score(test_labels, predictions),
        "Prec": precision_score(test_labels, predictions),
        "Rec": recall_score(test_labels, predictions),
    }

    # Save model
    model_fpath = output_dir / "trained_model.pkl"
    model_fpath.write_bytes(pickle.dumps(automl))

    # Save predictions
    predictions_fpath = output_dir / "predictions.json"
    predictions_fpath.write_text(json.dumps(predictions.tolist(), indent=2))

    # Save results
    result_fpath = output_dir / "results.json"
    result_fpath.write_text(json.dumps(metrics, indent=2))


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data-dir", type=Path, required=True)
    p.add_argument(
        "--metric-subset/--no-metric-subset",
        dest="metric_subset",
        default=False,
        action=argparse.BooleanOptionalAction,
    )
    p.add_argument("--job-id", type=int, required=True)
    args = p.parse_args()
    run_train_autosklearn(args.data_dir, args.metric_subset, args.job_id)


if __name__ == "__main__":
    main()

