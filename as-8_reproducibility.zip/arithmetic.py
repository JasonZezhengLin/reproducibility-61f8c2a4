#!/usr/bin/env python3
"""Recompute the published-row arithmetic and finite candidate sets using Python's standard library."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import json,argparse
ap=argparse.ArgumentParser();ap.add_argument("--input",type=Path,required=True);ap.add_argument("--output",type=Path,required=True);a=ap.parse_args()
root=a.input.resolve()
initial=json.loads((root/"initial_rows.json").read_bytes())["rows"]
supp=json.loads((root/"supplemental_rows.json").read_bytes())
candidates=json.loads((root/"candidate_matrices.json").read_bytes())["rows"]
assert len(initial)==66 and len(supp)==163
initial_status=dict(Counter(r["comparison_status"] for r in initial));assert initial_status=={"comparable":19,"unresolved":30,"non_comparable":17}
strict=[];support=[]
def relation(f,tol,b):
 return "above" if f-tol>b else "below" if f+tol<b else "rounding_compatible"
for r in initial:
 if r["comparison_status"]!="comparable":continue
 b=F(2*r["n_positive"],2*r["n_positive"]+r["n_negative"])
 assert b==F(r["constant_positive_baseline_exact"])
 d=relation(F(str(r["F1"])),F(str(r["rounding_halfwidth"])),b)
 expected="rounding_compatible" if r["point_relation"] in ["exact_equal","within_reported_rounding"] else r["point_relation"]
 assert d==expected
 strict.append({"row_id":r["row_id"],"baseline":str(b),"direction":d})
for r in supp:
 if r["population_basis"]=="unresolved_population":
  assert r["comparison_direction"] is None;continue
 p=F(r["prevalence_numerator"],r["prevalence_denominator"]);b=2*p/(1+p)
 assert b==F(r["constant_positive_f1_exact"])
 d=relation(F(r["reported_f1"]),F(1,2*10**r["reported_decimal_places_on_unit_interval"]),b)
 assert d==r["comparison_direction"],(r["row_id"],d,r["comparison_direction"])
 support.append({"row_id":r["row_id"],"baseline":str(b),"direction":d,"population_basis":r["population_basis"]})
assert dict(Counter(r["direction"] for r in strict))=={"above":6,"below":12,"rounding_compatible":1}
assert dict(Counter(r["direction"] for r in support))=={"above":29,"below":120,"rounding_compatible":1}
byid={r["row_id"]:r for r in initial};enumerated=[];completed=[];total_states=0
for cr in candidates:
 r=byid[cr["row_id"]];tol=F(1,20000);iv={k:(F(str(r[k]))-tol,F(str(r[k]))+tol) for k in ["accuracy","precision","recall","F1"]}
 def fits(k,n,d):
  if d<=0:return False
  lo,hi=iv[k];return lo.numerator*d<=n*lo.denominator and n*hi.denominator<=hi.numerator*d
 found=[]
 for pos in range(1,341):
  for tp in range(pos+1):
   if not fits("recall",tp,pos):continue
   for fp in range(284):
    if not fits("precision",tp,tp+fp):continue
    fn=pos-tp
    if not fits("F1",2*tp,2*tp+fp+fn):continue
    for tn in range(284-fp):
     if fits("accuracy",tp+tn,pos+fp+tn):found.append((tp,fp,fn,tn))
 expected=sorted(tuple(x[k] for k in ["tp","fp","fn","tn"]) for x in cr["candidates"])
 assert sorted(found)==expected
 enumerated.append({"row_id":cr["row_id"],"matrices":[list(x) for x in sorted(found)]})
 for t,u,v,w in found:
  missing_pos=340-t-v;missing_neg=283-u-w;lo=None;hi=None;states=0
  for x in range(missing_pos+1):
   for y in range(missing_neg+1):
    n=2*(t+x);d=2*t+u+v+missing_pos+x+y;states+=1
    if lo is None or n*lo[1]<lo[0]*d:lo=(n,d)
    if hi is None or n*hi[1]>hi[0]*d:hi=(n,d)
  lo=F(*lo);hi=F(*hi);total_states+=states
  assert lo==F(2*t,2*t+u+v+missing_pos+missing_neg)
  assert hi==F(2*(t+missing_pos),2*t+u+v+2*missing_pos)
  assert F(2*t,2*t+u+v)<F(2*(t+v),2*(t+v)+u+w)
  completed.append({"row_id":cr["row_id"],"matrix":[t,u,v,w],"retained_n":t+u+v+w,"min":str(lo),"max":str(hi),"states":states,"full_comparator_relation":"both_sides" if lo<F(680,963)<hi else "below" if hi<F(680,963) else "other"})
assert total_states==276981 and len(completed)==12
assert Counter(x["full_comparator_relation"] for x in completed)=={"both_sides":11,"below":1}
assert next(x for x in completed if x["retained_n"]==580)["max"]=="126/179"
result={"initial_status":initial_status,"strict":strict,"supplemental":support,"supplemental_population_bases":dict(Counter(r["population_basis"] for r in supp)),"complete_integer_sets":enumerated,"completion_bounds":completed,"total_completion_states":total_states,"all_assertions_passed":True,"scope":"Arithmetic replay of fixed published-condition rows. Does not recreate source extraction, historical model predictions, failed responses or paper-wide prevalence."}
a.output.parent.mkdir(parents=True,exist_ok=True)
with a.output.open("x") as f:json.dump(result,f,indent=2)
print(json.dumps({"all_assertions_passed":True,"initial_rows":len(initial),"supplemental_rows":len(supp),"candidate_matrices":len(completed),"completion_states":total_states}))
