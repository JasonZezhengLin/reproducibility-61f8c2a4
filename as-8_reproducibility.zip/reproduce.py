#!/usr/bin/env python3
from pathlib import Path
from collections import Counter
from fractions import Fraction
import argparse,ast,json,re,subprocess,sys
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
root=Path(__file__).resolve().parent;out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
c=subprocess.run([sys.executable,'-B',str(root/'arithmetic.py'),'--input',str(root),'--output',str(out/'arithmetic.json')],capture_output=True,text=True)
assert c.returncode==0,(c.stdout,c.stderr)
historical=json.loads((root/'historical_labels.json').read_text());counts={}
for name,labels in historical.items():
 assert all(type(x) is int and x in [0,1] for x in labels)
 counter=Counter(labels);counts[name]={'records':len(labels),'positive':counter[1],'negative':counter[0]}
expected={'BigVul':(1170,585,585),'Devign':(1873,852,1021),'Juliet':(3152,1576,1576),'DiverseVul':(1532,766,766),'CVEfixes':(4216,2108,2108),'ReVeal':(2028,1014,1014)}
for n,v in expected.items():assert tuple(counts[n][k] for k in ['records','positive','negative'])==v
current=json.loads((root/'current_labels.json').read_text());assert all(type(x) is int and x in [0,1] for x in current)
cs=Counter(current);assert len(current)==24788 and cs=={0:24239,1:549}
b=Fraction(2*cs[1],2*cs[1]+cs[0]);assert b==Fraction(1098,25337)
comparisons=json.loads((root/'current_file_comparisons.json').read_text());assert len(comparisons)==6
for row in comparisons:assert Fraction(str(row['paper_F1']))-Fraction(1,20000)>b and row['strict_report_status']=='unresolved'
supp=json.loads((root/'supplemental_rows.json').read_text());unbound=[x for x in supp if x['population_basis']=='unresolved_population'];assert len(unbound)==13
build=(root/'sources/build.sh').read_text().splitlines();exitlines=[i for i,s in enumerate(build,1) if re.fullmatch(r'\s*exit\s+0\s*',s)];downloadlines=[i for i,s in enumerate(build,1) if '1ABV5cIdtyNAzKlGxjW_BsFZOp9MFd-AH' in s and s.lstrip().startswith('wget ')]
assert exitlines==[28] and downloadlines==[44]
tree=ast.parse((root/'sources/train.py').read_text());calls=[x for x in ast.walk(tree) if isinstance(x,ast.Call) and ast.unparse(x.func)=='np.random.choice']
assert len(calls)==1 and len(calls[0].args)==2 and not calls[0].keywords and ast.unparse(calls[0].args[1])=='int(len(train_scaled) * 0.9)'
dt=ast.parse((root/'sources/dataset.py').read_text());load=next(x for x in dt.body if isinstance(x,ast.FunctionDef) and x.name=='load_data');ret=next(x for x in load.body if isinstance(x,ast.Return)).value
assert isinstance(ret,ast.ListComp) and len(ret.generators)==1 and not ret.generators[0].ifs and ast.unparse(ret.generators[0].iter)=='samples'
assert [ast.unparse(x) for x in ret.elt.values]==["function['func']","function['target']"]
create=next(x for x in dt.body if isinstance(x,ast.FunctionDef) and x.name=='run_create_hf_dataset');assigns={ast.unparse(x.targets[0]):ast.unparse(x.value) for x in create.body if isinstance(x,ast.Assign) and len(x.targets)==1}
assert assigns['test_path']=="raw_path / 'primevul_test.jsonl'" and assigns['test_data']=='load_data(test_path)' and assigns['test_dataset']=='Dataset.from_list(test_data)'
result={'historical_label_counts':counts,'historical_Devign_report_size':1312,'Devign_scored_population':'unresolved','Devign_conditions_with_unresolved_population':len(unbound),'current_file_records':len(current),'current_file_positive':cs[1],'current_file_negative':cs[0],'current_file_constant_F1':str(b),'conditional_comparisons_above_constant':len(comparisons),'build_exit_line':exitlines[0],'build_download_line':downloadlines[0],'training_sample_expression':ast.unparse(calls[0]),'dataset_maps_all_supplied_labels':True}
(out/'source_facts.json').write_text(json.dumps(result,indent=2)+'\n')
for f in out.glob('*.json'):
 e=root/'expected'/f.name
 if e.exists():assert json.loads(e.read_text())==json.loads(f.read_text()),f.name
print(json.dumps({'initial_conditions':66,'supplemental_conditions':163,'candidate_matrices':12,'completion_states':276981,'historical_datasets':len(counts),'current_file_records':len(current)}))
